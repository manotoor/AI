Mano Toor
Please open the report to see guide
to compile and run
javac eightPuzzle.java
java eightPuzzle