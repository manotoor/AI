/* 
 * Enumeration for movement types
 */
public enum MovementType {
	UP,
    DOWN,
    LEFT,
    RIGHT;
}
