/*
 * Enumeration for determining which Heuristic to use for A*
 */
public enum Heuristic {
	ONE,
    TWO
}
