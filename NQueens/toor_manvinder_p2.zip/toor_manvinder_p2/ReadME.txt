To run
Navigate to bin directory
in command prompt
java Test > a.txt

to compile
go to src
javac Test.java
should auto compile everything needed